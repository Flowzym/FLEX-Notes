@echo off
setlocal
cd /d "%~dp0"
set "FLEX_PREVIEW_EXE=%~dp0bin\flex-preview-windows-amd64.exe"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "FLEX_PREVIEW_EXE=%~dp0bin\flex-preview-windows-arm64.exe"
if /i "%PROCESSOR_ARCHITEW6432%"=="ARM64" set "FLEX_PREVIEW_EXE=%~dp0bin\flex-preview-windows-arm64.exe"
if not exist "%FLEX_PREVIEW_EXE%" (
  echo Vorschau-Server fehlt. Bitte das gesamte neue ZIP entpacken.
  pause
  exit /b 1
)
"%FLEX_PREVIEW_EXE%"
if errorlevel 1 pause
